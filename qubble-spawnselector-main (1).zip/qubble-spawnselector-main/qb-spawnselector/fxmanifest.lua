fx_version 'bodacious'
games { 'rdr3', 'gta5' }
version '1.0.0'

client_script 'client.lua'
client_script 'settings.lua'

ui_page('interface/interface.html')

files {
    'interface/interface.html',
   'interface/*',
} 

